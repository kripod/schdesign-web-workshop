/*

Error card HTML:

  <div class="card shadow">
     <h2>Error text.</h2>
  </div>


Song card HTML:

  <div class="card shadow link" onclick="window.open('url')">
    <div class="image-container" style="background-image: url('image')"></div>
    <div class="description">
      <h2>title</h2> 
      <h3>by artist</h3>
      <h4>listeners</h4>
    </div>
  </div>

*/
