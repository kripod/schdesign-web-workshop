/*
Hogyan szerezz tokent?

Készíts egy új felhasználót / jelentkezz be:
https://www.last.fm/join

Regisztrálj egy tokenért:
https://secure.last.fm/login?next=/api/account/create

Már használhatod is:
https://www.last.fm/api/show/artist.getSimilar
*/

const apiWrapper = new ApiWrapper("your token goes here");

apiWrapper.magicQuery(
  "Pitbull",
  { artistLimit: 6, songLimit: 4, length: 15 },
  console.log,
  console.error
);
